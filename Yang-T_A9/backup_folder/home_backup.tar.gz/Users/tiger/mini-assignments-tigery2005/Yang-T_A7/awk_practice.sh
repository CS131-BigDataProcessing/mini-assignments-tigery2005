#!/bin/bash

awk 'NR > 1 {count++} END {print count}' airline_stats.csv 

awk 'NR > 1 {sum += $1; count ++} END {print sum / count}' airline_stats.csv

awk -F, 'NR > 1 {if ($1 > 10) {count++}} END {print count}' airline_stats.csv

awk -F, 'NR > 1 {count++; if ($3 == 0) {count2++}} END {print count2/count}' airline_stats.csv






