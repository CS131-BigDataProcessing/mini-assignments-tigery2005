#!/bin/bash
awk 'NR > 1 {sum += $1; count ++} END {print sum / count}' airline_stats.csv
