#!/bin/bash

python3 unit_testing.py
